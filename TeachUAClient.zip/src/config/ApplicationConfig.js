export const ROOT_SERVER = "http://localhost:8080";
export const ROOT_URI = "/dev";

export const BASE_URL = ROOT_SERVER + ROOT_URI;
