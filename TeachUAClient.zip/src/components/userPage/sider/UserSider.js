import MenuSiderComponent from "./MenuSider";

const SiderComponent = () => {
    return (
        <div className="sider">
            <MenuSiderComponent/>
        </div>
    );
};

export default SiderComponent;